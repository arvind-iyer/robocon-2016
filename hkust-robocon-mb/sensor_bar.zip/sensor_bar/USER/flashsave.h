#ifndef __FLASHSAVE_H
#define __FLASHSAVE_H
#include "stm32f10x.h"
#include "stm32f10x_flash.h"


void writeFlash(void);
void readFlash(void);

#endif
