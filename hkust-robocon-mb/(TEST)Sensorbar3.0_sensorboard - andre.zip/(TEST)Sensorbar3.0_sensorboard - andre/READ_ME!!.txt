SensorBarV3.0	Program V1.0

Author: James Mok

Discription:
This device is used for differentiate different colours by memorize the target colours.

It compares the pre-stored colour's RGB value to that of the colour it is looking at.


How to use (DO IT ONCE AFTER EVERY RESET):
1)	Press both button A and B at the same time to enter calibrate mode. 

2)	Once entered calibrate mode, the tri-coloured LED should be off.	
	Aim the sensor at white colour, press B for normalize the input.

3)	The tri-coloured LED brinks, afterward it wil off. Press B to start memorize 
	the colour you needed. (number of colour which can be stored can be changed at colour_calculation.h --"list_num")

4)	After memorize all the colour you nedd, press B again to exit calibrate mode

5)	Enjoy your sensor!

